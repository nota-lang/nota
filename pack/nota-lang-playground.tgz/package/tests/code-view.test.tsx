/**
 * Output-pane view tests (CM6-highlighted, read-only viewers). Three concerns:
 *   1. `jsLanguage`/`htmlLanguage`/`jsonLanguage` wire a Lezer parser + the shared Catppuccin
 *      highlight — a mistyped tag throws at define-time, so we assert each constructs.
 *   2. `CodePane` formats its `code` (async Prettier) into a *read-only* `CodeView`.
 *   3. `SsgPane` composes the build artifacts: HTML + doc.compiled.mjs + client.entry.mjs.
 * Runs headless in jsdom; CM6 still builds its content DOM, so we assert against `.cm-content`.
 */

import { generateClientEntry } from "@nota-lang/vite/registry";
import { render, waitFor } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { CodePane } from "../src/CodePane";
import { CodeView } from "../src/CodeView";
import { GOLDEN_NOTA } from "../src/golden";
import { htmlLanguage } from "../src/html-mode";
import { jsLanguage } from "../src/js-mode";
import { jsonLanguage } from "../src/json-mode";
import { SsgPane } from "../src/SsgPane";
import { runSSG } from "../src/ssg";
import { compileNota } from "./util";

describe("language extensions build without throwing", () => {
  // The real failure mode is a mistyped `@lezer/highlight` tag — it throws when the style is defined.
  it.each([
    ["js", jsLanguage],
    ["html", htmlLanguage],
    ["json", jsonLanguage]
  ])("%s", (_name, lang) => {
    const ext = lang();
    expect(Array.isArray(ext)).toBe(true);
    expect((ext as unknown[]).length).toBeGreaterThan(0);
  });
});

describe("CodeView", () => {
  it("mounts a read-only CM6 editor showing the value", async () => {
    const { container } = render(
      <CodeView value={'h("span", {}, [x]);'} language={jsLanguage()} />
    );
    await waitFor(() =>
      expect(container.querySelector(".cm-editor")).toBeTruthy()
    );

    const content = container.querySelector(".cm-content");
    expect(content?.getAttribute("contenteditable")).toBe("false");
    expect(content?.textContent).toContain('h("span"');
  });
});

describe("CodePane", () => {
  it("Prettier-formats the emitted code into the viewer", async () => {
    const { getByTestId, container } = render(
      <CodePane code={"const  x=1\n"} mode="js" testid="pane-js" fill />
    );
    expect(getByTestId("pane-js")).toBeTruthy();
    // The async format normalizes the messy spacing to canonical `const x = 1;`.
    await waitFor(() =>
      expect(container.querySelector(".cm-content")?.textContent).toContain(
        "const x = 1;"
      )
    );
  });
});

describe("SsgPane", () => {
  it("shows read-only HTML, doc.compiled.mjs, and client.entry.mjs blocks", async () => {
    const full = compileNota(GOLDEN_NOTA);
    const { html } = runSSG(full);
    const clientJs = generateClientEntry({
      moduleId: "./doc.compiled.mjs"
    });
    const { getByTestId } = render(
      <SsgPane html={html} compiledJs={full} clientJs={clientJs} />
    );

    const htmlPane = getByTestId("pane-ssg-html");
    const compiledPane = getByTestId("pane-ssg-compiled");
    const clientPane = getByTestId("pane-ssg-client-js");

    await waitFor(() =>
      expect(htmlPane.querySelector(".cm-editor")).toBeTruthy()
    );
    await waitFor(() =>
      expect(clientPane.querySelector(".cm-editor")).toBeTruthy()
    );
    // All blocks are read-only CM6 views.
    for (const pane of [htmlPane, compiledPane, clientPane]) {
      expect(
        pane.querySelector(".cm-content")?.getAttribute("contenteditable")
      ).toBe("false");
    }
    // The document module block shows the compiled emit (runtime import + exported Doc).
    const compiledText = compiledPane.querySelector(".cm-content")?.textContent;
    expect(compiledText).toContain('from "@nota-lang/runtime"');
    expect(compiledText).toContain("Colorized");
    // The hydration entry shows the replay wiring (Prettier-formatted JS, highlighted):
    // import Doc + hydrateDocument(Doc); no manifest is embedded (debug metadata only).
    const clientText = clientPane.querySelector(".cm-content")?.textContent;
    expect(clientText).toContain("hydrateDocument(Doc)");
    expect(clientText).toContain("setAdapter(adapter)");
    expect(clientText).not.toContain("manifest");
  });

  it("an island-free doc shows the zero-JS note instead of a client-entry block", () => {
    const { getByTestId, queryByTestId } = render(
      <SsgPane
        html="<p>hi</p>"
        compiledJs="export default function Doc() {}"
        clientJs=""
      />
    );
    expect(getByTestId("pane-ssg-client-js-empty").textContent).toContain(
      "zero-JS"
    );
    expect(queryByTestId("pane-ssg-client-js")).toBeNull();
    expect(getByTestId("pane-ssg-compiled")).toBeTruthy();
  });
});
